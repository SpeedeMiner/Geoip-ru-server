# Project execution journal — Geoip-ru-server (post-v38)

**Purpose:** durable cross-chat state. This journal supersedes the stale pre-release status in the earlier PR #8 branch journal. Append new records; do not erase prior evidence.  
**Repository:** `SpeedeMiner/Geoip-ru-server`  
**Checkpoint UTC:** 2026-11-11 17:54 UTC (Asia/Almaty 22:54 UTC+5).  
**Current audit branch:** `audit/v38-postrelease-prefix-review-2026-11` (PR #10, Draft).

## 0. Non-negotiable boundaries

- Never inspect, edit, test, dispatch workflows for, rebase, merge or otherwise touch PR #5 or `feature/reachability-full-ru-kz-by`; another agent owns it.
- PR #6, #7 and #8 remain separate OPEN/DRAFT review branches. Do not edit, mark ready, merge or include them in PR #10.
- PR #9 is closed/merged. It is the only production change authorized in the previous stage.
- PR #10 is a separate audit-only follow-up. Do not merge without an explicit owner decision.
- Do not change production `main`, `release`, v38 GeoIP data, policy, inputs, tags, release assets or CDN from this audit branch.
- The client contract is still two categories only: `RU` (unified regional/service DIRECT bucket) and `PRIVATE` (absolute precedence). Explicit approved RKN exclusions override DIRECT.
- Every unresolved exact-prefix, source, routing or RPKI row remains REVIEW until a separate evidence-based decision is recorded. No automatic prefix promotion or removal.
- No Antifilter BGP registration or private-AS customer RIB was captured. Community `65444:210` membership remains NOT MEASURED, not zero and not inferable from public lists.

## 1. Current verified repository state

| Ref / PR | State | Branch / SHA | Meaning |
|---|---|---|---|
| `main` | production | `6c856d5c4b16ff6a77ad507572a7017a4cfe2532` | v38 merge commit |
| `release` | production | `3033248ea54cb298bafded25ddcd2805d5f0e7ac` | v38 artifact branch |
| tag `latest-geoip-client-v38` | published | points to `6c856d5c4b16ff6a77ad507572a7017a4cfe2532` | GitHub Release v38 |
| PR #6 | OPEN / DRAFT | `audit/exact-origin-followup-2026-11` @ `9014b18a2f7bf4de9d4493d19b50f399b57b0e3e` | exact-NLRI/RPKI review queue; no changes allowed in this follow-up |
| PR #7 | OPEN / DRAFT | `docs/source-improvement-plan-2026-11` @ `3f3dbb51c999b0de833ebda233e7b02f8c082b35` | v37 source catalog and improvement plan; do not edit in this follow-up |
| PR #8 | OPEN / DRAFT | `experiment/vpn-route-candidate-build-2026-11` @ `4d46634fbd033d5b2fef6ae5d6367e7dc318c971` | VPN source candidates and 360-host enrichment; do not edit in this follow-up |
| PR #9 | CLOSED / MERGED | `feature/geoip-direct-rukzby-v38` @ `e1343711a1f91493df19c904698e65543c4aa913` | v38 build/release |
| PR #10 | OPEN / DRAFT | `audit/v38-postrelease-prefix-review-2026-11` | isolated v38 post-release review; current head recorded after initial commit |

Do not query or inspect PR #5 in future recovery checks.

## 2. v38 release — completed and verified

- PR #9 squash-merged at `6c856d5c4b16ff6a77ad507572a7017a4cfe2532`.
- Main production workflow #78: run `43071263217`, SUCCESS. Download/extract sources, build, protobuf validation, GitHub Release upload, release branch publication, URL/report stage all succeeded.
- GitHub Release: https://github.com/SpeedeMiner/Geoip-ru-server/releases/tag/latest-geoip-client-v38
- Tag `latest-geoip-client-v38` points to the v38 main merge commit.
- Release branch SHA `3033248ea54cb298bafded25ddcd2805d5f0e7ac`.
- Release contains 45 assets.
- `geoip_RU.dat`: 2,191,860 bytes; SHA-256 `e757c1b7b8ca5b47c11117784eb78ab25c59fbadc0f6ab55229827560db76800`.
- `geoip_RU_v38_manifest.json` SHA-256 `b6a288815699c6aee2c64f45838d322be23bb0a7342b7e2c58ebf5bd6f1593a0`.
- `geoip_RU_v38_blocked_ip_exclusions.txt` SHA-256 `df909b12b985b23080075821cedc5e2f73b7b1f89abcd9950293b400ce1e4a5d`.
- Decoded categories: RU 200,800 CIDRs; PRIVATE 151 CIDRs. RU address space: 53,095,207 IPv4 and 1,204,925,358,834,572,963,424,937,397,190,656 IPv6 addresses. v37→v38 delta: +476,098 IPv4 and +12,483,475,607,738,606,560,012,522,225,664 IPv6.
- 14,613 RIR inventory rows: RU 13,679, BY 141, KZ 793.
- `ipsum.lst` 19,025 /24s remain review-only; no bulk `/24` carving. Estimated potential additional DIRECT impact if all carved: 682,195 IPv4 addresses.
- Release workflow log confirms 10 jsDelivr purge checks completed `finished`; both providers `CF` and `FY` were `true` for every check.
- SHA-256 in release asset, checksum sidecar and manifest agrees.

## 3. No-BGP public-source fallback

- The v38 release did not require Antifilter BGP registration. No community `65444:210` snapshot is claimed.
- Pinned `bol-van/rulist` commit `f9ea9704544590bf0aff817acc73b7e00261a849` separates `reestr_ipban4.txt` and `reestr_resolved4.txt`.
- Among the 360 Lib4u/Jirnobruh residual host candidates: 17 were contained in 11 broader ipban4 CIDRs (no exact /32 match); 9 matched resolved4; 8 were also in the ipban4-covered group; 18 unique candidates matched at least one. All 360 remain review-only.
- `runetfreedom/russia-blocked-geoip` and `eduard256/russia-blocked-ips` are correlated/broad secondary sources, suitable for differential discovery but not as direct-IP authority or bulk carve.
- RIPE/RDAP run #23 on PR #8 completed for all 360 candidates; route/origin/RPKI data are supplemental. RDAP holder data were not usable in that run.
- Full pinned analysis: `docs/V38_PUBLIC_RKN_SOURCE_CROSSCHECK.md` on `main`.

## 4. Current PR #10 input and initial result

Source input is the immutable PR #6 run #146 artifact:
- Run: `42966833882`; artifact ID `13830514293`.
- ZIP SHA-256: `dd64ed5a9d1dd5341ee5f5ddfbe491d541d6b101d2a0ceaf56a963ea863f4ad3`.
- Source worklist: 56 unique priority prefixes, all REVIEW.
- Archived-invalid reconciliation: 19 unique prefixes, all REVIEW; all 19 are included in the 56.
- Derived target input: `review/v38_postrelease_prefix_targets_20261111.tsv` (56 rows), SHA-256 `14da67661b3477e965e1b1ddcabc80252601922e10e53a6bd054e051bc2ae24c`.

The v38 protobuf was independently decoded from the PR #9 run #77 candidate artifact (ZIP SHA-256 `20eda18b4e0c3f39737510cdd8c85492ff2ef82aa3dae7ec985f8f48f127407a`); its GeoIP bytes hash matches the final production Release. The blocked exclusion list also matches the production release digest.

Initial address-space reconciliation over all 56 target prefixes:
- 54 fully covered by v38 RU.
- 2 partially covered by v38 RU: `77.88.0.0/18` (16,383/16,384 addresses) and `87.250.224.0/19` (8,191/8,192 addresses); each has one address in the approved blocked set.
- 0 prefixes with any PRIVATE overlap.
- 2 prefixes with approved blocked overlap; those are exact policy carve-outs, not a reason to remove their whole parent networks.
- All 56 remain REVIEW; this address overlap result does not decide current BGP origin or RPKI status.

The new audit workflow collects four evidence sources for each target: RouteViews exact RIB, RouteViews timestamped VRP/RPKI, RIPEstat Routing Status and RIPEstat Looking Glass. RouteViews guest requests are rate-limited to >=1.1 sec; RIPEstat concurrency <=4. All raw payloads/hashes and timestamps are retained. API errors are not converted to route absence. It binds all overlap checks to the fixed production v38 release commit/hash.

## 5. Recovery instructions

1. Read this journal first. The PR #8 journal is older historical context and has stale v38 pre-release status.
2. Refresh PR #6–#10 metadata and `main`/`release` SHAs. Do not query or inspect PR #5.
3. Do not edit or merge PR #6–#8. They remain independent and Draft.
4. Check PR #10 Actions run for all 224 requests (4 sources × 56 prefixes), unit tests, artifact digest and report. If the workflow is still running, check the same run; do not create another event in the concurrency group.
5. Verify every request has status, time, URL, attempt count and raw body SHA. A failed/invalid response is incomplete evidence, not an empty route result.
6. Verify every summary row remains REVIEW; no exact origin/RPKI result is permission to change the production IP set without a distinct review.
7. Append a dated checkpoint below with PR #10 commit/run/artifact hashes and final route/address-space results. Do not merge PR #10 without explicit owner approval.
8. Preserve the no-BGP limitation: community `65444:210` remains unmeasured unless a real peer capture is later supplied.

## 6. Append-only log

### 2026-11-11 — v38 release and post-release audit continuation

- Verified PR #9 merged and v38 release fully published; workflow #78 `43071263217` succeeded.
- Re-read main, release, tag, manifest, checksum and quality report. Confirmed SHA/digest consistency and 45 release assets.
- Verified 10 jsDelivr purges returned `finished`, with CF/FY success.
- Rechecked PR #6/#7/#8 are open Draft at their recorded heads; no changes were made to those branches. PR #9 is closed/merged.
- Downloaded and SHA-verified PR #6 run #146 artifact. Confirmed 19 archived-invalid and 56 priority rows are all REVIEW; the 19 are a subset of the 56.
- Independently decoded the actual v38 protobuf and intersected each target prefix with RU/PRIVATE/approved blocked intervals. Results: 54 full RU, 2 partial due one blocked address each, zero PRIVATE overlap, two blocked-overlap prefixes.
- Created a separate branch `audit/v38-postrelease-prefix-review-2026-11` from immutable v38 main commit `6c856d5c4b16ff6a77ad507572a7017a4cfe2532`. No edits to PR #6–#8 or production refs.
- Next: finish and verify the PR #10 live exact-NLRI/RPKI capture, inspect its artifact, summarize all 56 rows and retain REVIEW status. Then continue the source-quality improvement plan with the v38 baseline, not the v37 baseline.
