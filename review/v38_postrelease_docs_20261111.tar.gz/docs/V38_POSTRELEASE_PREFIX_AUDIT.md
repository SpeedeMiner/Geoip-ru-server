# v38 post-release prefix audit — current-origin and RPKI follow-up

**Purpose:** refresh the existing exact-origin/RPKI review queue against the published v38 database and a new timestamped public RIB/VRP evidence capture. This is an audit-only follow-up; it does not amend production prefixes or change any prior review classification.

## Immutable baselines

- Repository: `SpeedeMiner/Geoip-ru-server`.
- Main commit containing v38: `6c856d5c4b16ff6a77ad507572a7017a4cfe2532`.
- Release branch commit: `3033248ea54cb298bafded25ddcd2805d5f0e7ac` (`Publish GeoIP DIRECT RU+BY+KZ CLIENT v38`).
- Release tag: `latest-geoip-client-v38`, pointing to the main merge commit above.
- Release URL: https://github.com/SpeedeMiner/Geoip-ru-server/releases/tag/latest-geoip-client-v38
- `geoip_RU.dat`: 2,191,860 bytes; SHA-256 `e757c1b7b8ca5b47c11117784eb78ab25c59fbadc0f6ab55229827560db76800`.
- `geoip_RU_v38_manifest.json` SHA-256: `b6a288815699c6aee2c64f45838d322be23bb0a7342b7e2c58ebf5bd6f1593a0`.
- `geoip_RU_v38_blocked_ip_exclusions.txt` SHA-256: `df909b12b985b23080075821cedc5e2f73b7b1f89abcd9950293b400ce1e4a5d`.
- v38 protobuf has exactly two categories: `RU` (200,800 CIDRs) and `PRIVATE` (151 CIDRs). PRIVATE precedence is absolute.

All files used for the address-space overlap comparison are tied to the immutable release-branch commit, not a mutable `release` name or current upstream feed.

## Pinned review queue input

The review targets are the 56 unique prefixes from PR #6 audit artifact:

- Prior audit workflow run: `42966833882` (PR #6 run #146).
- Artifact ID: `13830514293`.
- Artifact ZIP SHA-256: `dd64ed5a9d1dd5341ee5f5ddfbe491d541d6b101d2a0ceaf56a963ea863f4ad3`.
- Original `priority_prefix_review_worklist.tsv`: 56 unique rows, all `REVIEW`.
- Original `priority_prefix_rpki_invalid_reconciliation.tsv`: 19 unique rows, all `REVIEW`; all 19 are a subset of the 56-prefix worklist.
- Derived pinned input in this audit: `review/v38_postrelease_prefix_targets_20261111.tsv`, 56 rows, SHA-256 `14da67661b3477e965e1b1ddcabc80252601922e10e53a6bd054e051bc2ae24c`.

The target TSV preserves source artifact identity, prior archive origin observations, archived-invalid origin values, review priority and track. It is not a production source list.

## Address-space reconciliation against the actual v38 protobuf

The audit independently decoded the published GeoIP protobuf and merged address intervals, then intersected each target prefix with `RU`, `PRIVATE`, and the exact approved blocked set. This is address-space comparison, not a count of exact CIDR strings.

| Result | Prefixes |
|---|---:|
| Fully covered by v38 `RU` | 54 |
| Partially covered by v38 `RU` | 2 |
| No v38 `RU` coverage | 0 |
| Any `PRIVATE` overlap | 0 |
| Any approved blocked overlap | 2 |

The two partial rows are:

- `77.88.0.0/18`: 16,383 of 16,384 addresses are in RU; one address is an approved blocked exclusion.
- `87.250.224.0/19`: 8,191 of 8,192 addresses are in RU; one address is an approved blocked exclusion.

The other 54 prefixes are fully inside RU. None of the 56 target prefixes intersects PRIVATE. The approved blocked intersections are preserved as single-address policy carve-outs, not treated as evidence that the entire parent prefix should be removed.

This pre-capture intersection does not settle whether any origin is currently valid, invalid, present or absent in the global RIB. Those are separate evidence questions.

## Current-origin/RPKI capture

The dedicated CI workflow collects four independent observations for each of the 56 prefixes:

1. RouteViews exact-prefix RIB (`strict-match=yes`).
2. RouteViews timestamped VRP/RPKI lookup for the exact prefix.
3. RIPEstat Routing Status (including exact origins and more-specific count).
4. RIPEstat Looking Glass (24-hour lookback, including RRC and peer observations).

RouteViews unauthenticated requests are serialized at 1.1 seconds or slower. RIPEstat requests use at most four concurrent workers. Each response records URL, request/response UTC times, HTTP/transport status, attempt count, prior retry errors, byte count, body SHA-256 and parsed JSON. Raw observations are retained in a gzip JSONL artifact.

The output explicitly keeps RouteViews RIB route-level RPKI and RouteViews timestamped VRP status separate. It also records RIPEstat API query times. It does not assume the sources are synchronized, and it does not infer invalidity from a missing VRP entry or absence from one collector.

Expected CI output files:

- `exact_nlri_capture.json` — full JSON responses and per-request provenance.
- `raw_observations.jsonl.gz` — unabridged request records with response bodies and hashes.
- `v38_postrelease_prefix_review.tsv` — one row per target with current route evidence and v38 RU/PRIVATE/blocked address overlap.
- `manifest.json` — release/input hashes, target counts, capture status counts, VRP timestamps and review invariants.
- `README.txt` — artifact scope and limitations.

## Decision policy

- Every row remains `REVIEW` regardless of current route or RPKI result.
- A current valid ROA does not prove that an ASN is the legal owner of all addresses or that it is exclusively used by a named service.
- RPKI `unknown` is not `invalid`; a missing VRP record is not automatically `notfound` or invalid.
- More-specific NLRI must not be projected onto a parent prefix.
- An API error, malformed response or empty response with unknown semantics is recorded as incomplete evidence, not a route withdrawal.
- A current origin set differing from the archived origin set is a time-window discrepancy to review, not automatic proof of a bad prefix.
- No candidate is auto-added to or removed from `geoip_RU.dat`; the output is evidence only.

## Production and branch boundaries

- This audit does not change `main`, `release`, the v38 tag, assets, CDN, `geoip_RU.dat`, source registry, builder inputs, PRIVATE or the approved blocked set.
- It does not edit PR #6, #7 or #8 branches; the source queue was copied from the previously published PR #6 artifact as an immutable input.
- PR #5 and `feature/reachability-full-ru-kz-by` are outside scope and must not be inspected or touched.
- PR #9 is closed/merged and its v38 publication is complete.
- The new audit-only follow-up remains Draft until separately reviewed; no merge is implied.

## Next stage

After the dedicated CI capture finishes, verify the artifact ZIP digest, manifest, all 224 request records and per-request raw hashes. Summarize the 19 archived-invalid rows and 56 total rows without promoting or demoting any prefix. If a genuinely new synchronized VRP timestamp is not available, record that limitation rather than treating repeated RIB polls against the same VRP snapshot as independent evidence.
