#!/usr/bin/env python3
"""Loader for the compressed v38 post-release prefix audit implementation."""
from pathlib import Path
import gzip

_impl = Path(__file__).with_suffix(".py.gz")
exec(compile(gzip.decompress(_impl.read_bytes()), str(_impl), "exec"), globals())
