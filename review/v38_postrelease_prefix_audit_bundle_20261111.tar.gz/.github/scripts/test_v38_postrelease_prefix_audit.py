from __future__ import annotations

import hashlib
import ipaddress
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from collect_v38_postrelease_prefix_audit import (
    decode_geoip,
    evidence_agreement,
    merge_intervals,
    overlap_count,
    protobuf_fields,
    read_targets,
    reconcile_archived_invalid,
    summarize,
)


def varint(value: int) -> bytes:
    out = bytearray()
    while value > 0x7F:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def blob_field(number: int, value: bytes) -> bytes:
    return varint((number << 3) | 2) + varint(len(value)) + value


def int_field(number: int, value: int) -> bytes:
    return varint(number << 3) + varint(value)


class PostReleaseAuditTests(unittest.TestCase):
    def test_target_input_is_pinned_56_rows_and_19_archived_invalid(self):
        path = Path(__file__).parents[2] / "review" / "v38_postrelease_prefix_targets_20261111.tsv"
        rows = read_targets(path)
        self.assertEqual(len(rows), 56)
        self.assertEqual(sum(bool(x["ARCHIVED_INVALID_ORIGINS"]) for x in rows), 19)
        self.assertTrue(all(x["STATUS"] == "REVIEW" for x in rows))

    def test_protobuf_field_reader_decodes_wire_types(self):
        payload = blob_field(1, b"RU") + int_field(3, 7)
        parsed = list(protobuf_fields(payload))
        self.assertEqual(parsed, [(1, 2, b"RU"), (3, 0, 7)])

    def test_geoip_protobuf_decoder_reads_ru_and_private_categories(self):
        def cidr(ip: str, prefix: int) -> bytes:
            net = ipaddress.ip_network(f"{ip}/{prefix}", strict=False)
            return blob_field(1, net.network_address.packed) + int_field(2, prefix)

        ru = blob_field(1, b"RU") + blob_field(2, cidr("198.51.100.0", 24))
        private = blob_field(1, b"PRIVATE") + blob_field(2, cidr("10.0.0.0", 8))
        payload = blob_field(1, ru) + blob_field(1, private)
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "geoip_RU.dat"
            path.write_bytes(payload)
            with patch("collect_v38_postrelease_prefix_audit.GEOIP_SHA256", hashlib.sha256(payload).hexdigest()):
                decoded = decode_geoip(path)
        self.assertEqual(set(decoded), {"RU", "PRIVATE"})
        self.assertEqual(str(decoded["RU"][0]), "198.51.100.0/24")
        self.assertEqual(str(decoded["PRIVATE"][0]), "10.0.0.0/8")

    def test_interval_overlap_counts_address_space_not_cidr_rows(self):
        nets = [ipaddress.ip_network("10.0.0.0/25"), ipaddress.ip_network("10.0.0.128/25")]
        merged = merge_intervals(nets, 4)
        self.assertEqual(len(merged), 1)
        self.assertEqual(overlap_count(ipaddress.ip_network("10.0.0.0/24"), merged), 256)
        self.assertEqual(overlap_count(ipaddress.ip_network("10.0.1.0/24"), merged), 0)

    def test_exact_origin_agreement_requires_three_successful_source_sets(self):
        summary = {}
        for source in ("routeviews_exact_rib", "ripestat_routing_status", "ripestat_looking_glass_24h"):
            summary[("192.0.2.0/24", source)] = {"transport_status": "HTTP_OK", "exact_origins": ["64500"]}
        self.assertEqual(evidence_agreement(summary, "192.0.2.0/24"), "ALL_THREE_SOURCE_SETS_AGREE")
        summary[("192.0.2.0/24", "routeviews_exact_rib")]["transport_status"] = "HTTP_ERROR"
        self.assertEqual(evidence_agreement(summary, "192.0.2.0/24"), "PARTIAL_OR_FAILED_EVIDENCE")

    def test_archived_invalid_absence_is_review_not_approval(self):
        row = {"PREFIX": "192.0.2.0/24", "ARCHIVED_INVALID_ORIGINS": "AS64501"}
        summary = {("192.0.2.0/24", "routeviews_exact_rib"): {
            "transport_status": "HTTP_OK", "exact_origins": ["64500"], "route_level_rpki_by_origin": {"64500": "valid"}
        }}
        self.assertEqual(reconcile_archived_invalid(row, summary), "ARCHIVED_INVALID_ORIGIN_NOT_IN_CURRENT_EXACT_ORIGIN_SET_REVIEW")

    def test_archived_origin_field_accepts_comma_and_pipe_delimiters(self):
        row = {"PREFIX": "192.0.2.0/24", "ARCHIVED_INVALID_ORIGINS": "AS64501|AS64502"}
        summary = {("192.0.2.0/24", "routeviews_exact_rib"): {
            "transport_status": "HTTP_OK", "exact_origins": ["64501", "64502"],
            "route_level_rpki_by_origin": {"64501": "invalid_asn", "64502": "valid"}
        }}
        self.assertEqual(reconcile_archived_invalid(row, summary), "ARCHIVED_INVALID_ORIGIN_STILL_EXACT_ROUTEVIEW_INVALID_REVIEW")

    def test_routeviews_error_is_not_converted_to_empty_exact_rib(self):
        record = {
            "prefix": "192.0.2.0/24", "source": "routeviews_exact_rib", "transport_status": "HTTP_ERROR",
            "http_status": 503, "response_received_utc": "2026-11-11T00:00:00Z", "error": "HTTPError: 503",
            "response_json": None,
        }
        result = summarize(record)
        self.assertNotIn("exact_origins", result)
        self.assertEqual(result["transport_status"], "HTTP_ERROR")


if __name__ == "__main__":
    unittest.main()
