#!/usr/bin/env python3
"""Review-only enrichment of v38 Lib4u/Jirnobruh host-IP candidates.

Public RIPE RIS evidence is supplemental and never substitutes for the private
AS65444 Antifilter BGP session. This program never changes a GeoIP database.
"""
from __future__ import annotations
import argparse, concurrent.futures, csv, gzip, hashlib, ipaddress, json, re
import threading, time, urllib.error, urllib.parse, urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RIPE = "https://stat.ripe.net/data"
IANA_RDAP = "https://data.iana.org/rdap/ipv4.json"
UA = "Geoip-ru-server-v38-review/1.0"

SHARED = {
    "AMAZON_AWS": re.compile(r"amazon|aws|cloudfront|amazonaws", re.I),
    "CLOUDFLARE": re.compile(r"cloudflare", re.I),
    "GOOGLE_CLOUD": re.compile(r"google cloud|google llc|google inc|gcp", re.I),
    "MICROSOFT_AZURE": re.compile(r"microsoft|azure", re.I),
    "AKAMAI_LINODE": re.compile(r"akamai|linode", re.I),
    "FASTLY": re.compile(r"fastly", re.I),
    "ORACLE_CLOUD": re.compile(r"oracle cloud", re.I),
    "ALIBABA_CLOUD": re.compile(r"alibaba|aliyun", re.I),
    "TENCENT_CLOUD": re.compile(r"tencent cloud", re.I),
    "OVH": re.compile(r"ovhcloud|ovh sas", re.I),
    "HETZNER": re.compile(r"hetzner", re.I),
    "DIGITALOCEAN": re.compile(r"digitalocean", re.I),
    "VULTR_CHOOPA": re.compile(r"vultr|choopa", re.I),
    "LEASEWEB": re.compile(r"leaseweb", re.I),
    "GCORE": re.compile(r"gcore|g-core labs", re.I),
    "CDN77_DATACAMP": re.compile(r"cdn77|datacamp limited", re.I),
    "HOSTING_DATACENTER": re.compile(r"hosting|datacenter|data center|server farm|cloud infrastructure", re.I),
}
SHARED_DOMAIN = [re.compile(x, re.I) for x in (
    r"(^|\.)amazonaws\.com$", r"(^|\.)cloudfront\.net$", r"(^|\.)cloudflare\.com$",
    r"(^|\.)fastly\.net$", r"(^|\.)akamai(ed)?\.net$", r"(^|\.)azureedge\.net$",
    r"(^|\.)trafficmanager\.net$",
)]


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def data_of(payload: dict[str, Any]) -> dict[str, Any]:
    return payload.get("data") if isinstance(payload.get("data"), dict) else {}


def asn_name(value: Any) -> str:
    value = str(value or "").strip().upper()
    return value if value.startswith("AS") else ("AS" + value if value else "")


def global_v4(value: str) -> str:
    addr = ipaddress.ip_address(value.strip())
    if addr.version != 4 or not addr.is_global:
        raise ValueError(f"not a globally routable IPv4 address: {value}")
    return str(addr)


def load_candidates(path: Path) -> list[dict[str, str]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    if not rows:
        raise ValueError("empty candidate input")
    seen = set()
    for row in rows:
        ip = global_v4(row["ip"])
        if ip in seen:
            raise ValueError(f"duplicate candidate: {ip}")
        seen.add(ip)
        if row.get("prefix") != ip + "/32":
            raise ValueError(f"non-canonical candidate prefix: {row.get('prefix')}")
        for field in ("in_v38_ru", "in_private", "in_approved_blocked"):
            if row.get(field, "").lower() == "true":
                raise ValueError(f"candidate overlaps v38 policy ({field}): {ip}")
    return rows


class Recorder:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        self.file = gzip.open(path, "wt", encoding="utf-8")

    def add(self, endpoint: str, url: str, status: int | None, body: bytes | None, error: str = "") -> None:
        parsed: Any = None
        if body:
            try:
                parsed = json.loads(body.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                parsed = body[:2048].decode("utf-8", "replace")
        item = {"captured_at_utc": now(), "endpoint": endpoint, "url": url,
                "http_status": status, "body_sha256": digest(body) if body is not None else "",
                "body": parsed, "error": error}
        with self.lock:
            self.file.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
            self.file.flush()

    def close(self) -> None:
        self.file.close()


class Client:
    def __init__(self, recorder: Recorder, timeout: int = 25, retries: int = 3):
        self.recorder, self.timeout, self.retries = recorder, timeout, retries
        self.lock = threading.Lock()
        self.count = 0
        self.errors: Counter[str] = Counter()

    def get(self, endpoint: str, url: str) -> dict[str, Any]:
        last = ""
        for attempt in range(self.retries + 1):
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
            with self.lock:
                self.count += 1
            try:
                with urllib.request.urlopen(req, timeout=self.timeout) as response:
                    body = response.read(8 * 1024 * 1024 + 1)
                    if len(body) > 8 * 1024 * 1024:
                        raise ValueError("response exceeds 8 MiB limit")
                    status = response.status
                self.recorder.add(endpoint, url, status, body)
                result = json.loads(body.decode("utf-8"))
                if result.get("status") not in (None, "ok", "OK"):
                    self.errors[endpoint + ":api_status"] += 1
                return result
            except urllib.error.HTTPError as exc:
                body = exc.read(1024 * 1024)
                last = f"HTTP {exc.code}: {body[:300].decode('utf-8','replace')}"
                self.recorder.add(endpoint, url, exc.code, body, last)
                if exc.code not in (429, 500, 502, 503, 504) or attempt == self.retries:
                    break
                try:
                    wait = min(30.0, max(1.0, float(exc.headers.get("Retry-After", ""))))
                except ValueError:
                    wait = min(12.0, 2 ** attempt)
                time.sleep(wait)
            except (OSError, TimeoutError, ValueError, json.JSONDecodeError) as exc:
                last = f"{type(exc).__name__}: {exc}"
                self.recorder.add(endpoint, url, None, None, last)
                if attempt == self.retries:
                    break
                time.sleep(min(8.0, 2 ** attempt))
        self.errors[endpoint] += 1
        return {"status": "error", "messages": [last], "data": {}}


def ripe_url(endpoint: str, **params: str) -> str:
    params["sourceapp"] = "geoip-ru-server-v38-review"
    return f"{RIPE}/{endpoint}/data.json?{urllib.parse.urlencode(params)}"


def parallel(keys: list[Any], fn, workers: int) -> dict[Any, Any]:
    out = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(fn, key): key for key in keys}
        for future in concurrent.futures.as_completed(futures):
            key = futures[future]
            try:
                out[key] = future.result()
            except Exception as exc:
                out[key] = {"status": "error", "messages": [f"{type(exc).__name__}: {exc}"], "data": {}}
    return out


def route_objects(origins: list[dict[str, Any]]) -> str:
    parts = []
    for item in origins:
        asn = asn_name(item.get("origin"))
        objs = item.get("route_objects") or []
        values = []
        for obj in objs:
            if isinstance(obj, str):
                values.append(obj)
            elif isinstance(obj, dict):
                values.append("/".join(str(obj[k]) for k in ("source", "route", "origin") if obj.get(k) is not None))
        parts.append(asn + ":" + (",".join(values) if values else "NO_EXACT_ROUTE_OBJECT"))
    return ";".join(parts)


def rdap_server(ip: str, bootstrap: dict[str, Any]) -> str:
    addr = ipaddress.ip_address(ip)
    matches = []
    for prefixes, urls in bootstrap.get("services", []):
        for prefix in prefixes:
            try:
                network = ipaddress.ip_network(prefix, strict=False)
            except ValueError:
                continue
            if addr in network and urls:
                matches.append((network.prefixlen, urls[0]))
    if not matches:
        raise ValueError(f"IANA RDAP bootstrap has no server for {ip}")
    return max(matches)[1]


def rdap_holder(obj: dict[str, Any]) -> str:
    names: list[str] = []
    def walk(value: Any) -> None:
        if isinstance(value, dict):
            if isinstance(value.get("name"), str): names.append(value["name"])
            vcard = value.get("vcardArray")
            if isinstance(vcard, list) and len(vcard) > 1 and isinstance(vcard[1], list):
                for entry in vcard[1]:
                    if isinstance(entry, list) and len(entry) >= 4 and entry[0] in ("fn", "org"):
                        names.append(" ".join(map(str, entry[3])) if isinstance(entry[3], list) else str(entry[3]))
            for key, child in value.items():
                if key != "vcardArray": walk(child)
        elif isinstance(value, list):
            for child in value: walk(child)
    walk(obj)
    return " | ".join(dict.fromkeys(re.sub(r"\s+", " ", x).strip() for x in names if x.strip()))[:1200]


def shared_flags(as_holders: str, rdap_text: str, hostnames: str) -> list[str]:
    names = as_holders + " " + rdap_text
    flags = {key for key, pattern in SHARED.items() if pattern.search(names)}
    domains = [x.strip().lower().rstrip(".") for x in re.split(r"[;,| ]+", hostnames) if x.strip()]
    if any(pattern.search(domain) for domain in domains for pattern in SHARED_DOMAIN):
        flags.add("SHARED_CLOUD_OR_CDN_HOSTNAME")
    return sorted(flags)


def enrich(input_path: Path, output_dir: Path, workers: int = 4) -> dict[str, Any]:
    if not 1 <= workers <= 8:
        raise ValueError("workers must be 1..8")
    rows = load_candidates(input_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    recorder = Recorder(output_dir / "raw_lookup_responses.jsonl.gz")
    api = Client(recorder)
    started = now()
    input_hash = digest(input_path.read_bytes())
    try:
        # RISwhois 8-hour dump: not a dedicated, instant BGP table.
        def ni(ip: str): return api.get("network-info", ripe_url("network-info", resource=ip))
        network_info = parallel([r["ip"] for r in rows], ni, workers)
        prefixes = sorted({str(data_of(v).get("prefix")) for v in network_info.values() if data_of(v).get("prefix")})

        # The RIS routing-status result is the public exact-origin and IRR evidence.
        def rs(prefix: str): return api.get("routing-status", ripe_url("routing-status", resource=prefix, min_peers_seeing="0"))
        routing = parallel(prefixes, rs, workers)
        pairs, asns = set(), set()
        for prefix, payload in routing.items():
            for origin in data_of(payload).get("origins", []) or []:
                asn = asn_name(origin.get("origin"))
                if asn: pairs.add((prefix, asn)); asns.add(asn)

        def ao(asn: str): return api.get("as-overview", ripe_url("as-overview", resource=asn))
        holders = parallel(sorted(asns), ao, workers)
        def rp(pair):
            prefix, asn = pair
            return api.get("rpki-validation", ripe_url("rpki-validation", resource=asn, prefix=prefix))
        rpki = parallel(sorted(pairs), rp, workers)

        bootstrap_result = api.get("iana-rdap-ipv4-bootstrap", IANA_RDAP)
        bootstrap = bootstrap_result if "services" in bootstrap_result else data_of(bootstrap_result)
        rdap_targets = {}
        for row in rows:
            prefix = data_of(network_info[row["ip"]]).get("prefix")
            rdap_targets.setdefault(str(prefix) if prefix else row["ip"], row["ip"])
        def rlookup(target):
            key, ip = target
            try:
                base = rdap_server(ip, bootstrap)
                url = urllib.parse.urljoin(base.rstrip("/") + "/", "ip/" + urllib.parse.quote(ip, safe=""))
            except Exception as exc:
                return {"status": "error", "messages": [str(exc)], "data": {}}
            result = api.get("rdap-ip", url)
            result["_source_url"] = url
            return result
        rdap = parallel(sorted(rdap_targets.items()), rlookup, workers)

        result_rows = []
        for row in rows:
            ip = row["ip"]
            ni_data = data_of(network_info[ip])
            prefix = str(ni_data.get("prefix") or "")
            route_data = data_of(routing.get(prefix, {}))
            origins = route_data.get("origins", []) or []
            origin_asns = sorted({asn_name(o.get("origin")) for o in origins if o.get("origin")})
            holders_out, rpki_out = [], []
            for asn in origin_asns:
                holder = data_of(holders.get(asn, {})).get("holder") or "HOLDER_UNKNOWN"
                holders_out.append(f"{asn}={holder}")
                state = data_of(rpki.get((prefix, asn), {})).get("status") or "NOT_MEASURED"
                rpki_out.append(f"{asn}={state}")
            rdap_payload = rdap.get(prefix if prefix else ip, {})
            rd = rdap_payload if isinstance(rdap_payload, dict) and "data" not in rdap_payload else data_of(rdap_payload)
            rd_holder = rdap_holder(rd)
            rd_network = "/".join(str(rd.get(k, "")) for k in ("name", "handle", "startAddress", "endAddress") if rd.get(k))
            flags = shared_flags(";".join(holders_out), rd_holder + " " + rd_network, row.get("hostnames", ""))
            route_state = "ROUTE_OBSERVED" if origins else ("NO_ORIGIN_IN_RIS_SNAPSHOT" if prefix else "NO_RIS_PREFIX_FOR_IP")
            exact_irr = any(o.get("route_objects") for o in origins)
            reasons = ["ALWAYS_REVIEW"]
            if not origins: reasons.append(route_state)
            if len(origin_asns) > 1: reasons.append("MOAS")
            if not exact_irr: reasons.append("NO_EXACT_IRR_ROUTE_OBJECT")
            if any(x.endswith("=invalid_asn") or x.endswith("=invalid_length") for x in rpki_out): reasons.append("RPKI_INVALID_PAIR")
            if any(x.endswith("=unknown") for x in rpki_out): reasons.append("RPKI_UNKNOWN_PAIR")
            reasons.extend(flags)
            if any(x.get("status") == "error" for x in (network_info[ip], routing.get(prefix, {}), rdap_payload)):
                reasons.append("LOOKUP_ERROR_OR_UNAVAILABLE")
            result_rows.append({
                "ip": ip, "prefix": row.get("prefix", ""), "source_ids": row.get("source_ids", ""),
                "hostnames": row.get("hostnames", ""), "route_prefix": prefix, "route_state": route_state,
                "origin_asns": ";".join(origin_asns), "asn_holders": ";".join(holders_out),
                "rpki_by_origin": ";".join(rpki_out), "irr_exact_route_objects": route_objects(origins),
                "visibility_json": json.dumps(route_data.get("visibility", {}), ensure_ascii=False, sort_keys=True),
                "network_info_query_time": str(ni_data.get("query_time") or ""),
                "routing_status_query_time": str(route_data.get("query_time") or ""),
                "rdap_holder": rd_holder, "rdap_network": rd_network, "rdap_country": str(rd.get("country") or ""),
                "shared_provider_flags": ";".join(flags), "review_reasons": ";".join(dict.fromkeys(reasons)),
                "decision": "REVIEW_ONLY_NO_AUTO_PROMOTION",
            })
        tsv = output_dir / "v38_pr8_host_ip_live_enrichment.tsv"
        with tsv.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(result_rows[0]), delimiter="\t", lineterminator="\n")
            writer.writeheader(); writer.writerows(result_rows)
        route_counts = Counter(x["route_state"] for x in result_rows)
        rpki_counts = Counter()
        for row in result_rows:
            for value in row["rpki_by_origin"].split(";"):
                if "=" in value: rpki_counts[value.rsplit("=", 1)[1]] += 1
        flag_counts = Counter(flag for row in result_rows for flag in row["shared_provider_flags"].split(";") if flag)
        manifest = {
            "schema_version": 1, "purpose": "review-only; no automatic DIRECT/PROXY mutation",
            "capture_started_utc": started, "capture_finished_utc": now(),
            "candidate_count": len(rows), "candidate_input_sha256": input_hash,
            "ripe_stat": {
                "source": "RIPE RIS public Data API", "network_info_methodology": "RISwhois 8-hour dumps",
                "routing_status_methodology": "latest RIS collection, usually 00:00/08:00/16:00 UTC",
                "candidate_ips_queried": len(network_info), "distinct_prefixes_queried": len(prefixes),
                "prefix_origin_pairs": len(pairs), "distinct_asns_queried": len(asns),
                "raw_requests_including_retries": api.count, "workers": workers,
            },
            "rdap": {"bootstrap": IANA_RDAP, "distinct_route_or_unannounced_ip_queries": len(rdap_targets)},
            "summary": {"route_state_counts": dict(route_counts), "rpki_pair_status_counts": dict(rpki_counts),
                        "shared_provider_flags": dict(flag_counts), "api_errors": dict(api.errors),
                        "all_candidates_remain_review": True},
            "interpretation_limits": [
                "RIPE RIS does not replace the dedicated Antifilter AS65444 session and cannot establish 65444:210 membership.",
                "network-info is based on RISwhois 8-hour dumps; routing-status has its own RIS query_time.",
                "No RIS route is not proof of non-use, safety or absence from a blocklist.",
                "RPKI unknown is not invalid. RPKI valid is not proof of service ownership.",
                "IRR exact route objects and RDAP holder labels are corroborating evidence, not exclusive service-use proof.",
                "Shared provider flags are conservative heuristics, not automatic rejection or approval.",
                "All candidates remain REVIEW; no production inputs or client GeoIP are modified.",
            ],
            "documentation": {"network_info": "https://stat.ripe.net/docs/data-api/api-endpoints/network-info.html",
                "routing_status": "https://stat.ripe.net/docs/data-api/api-endpoints/routing-status",
                "rpki_validation": "https://stat.ripe.net/docs/data-api/api-endpoints/rpki-validation",
                "as_overview": "https://stat.ripe.net/docs/data-api/api-endpoints/as-overview", "rdap_bootstrap": IANA_RDAP},
            "output_sha256": digest(tsv.read_bytes()),
        }
        (output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
        return manifest
    finally:
        recorder.close()


# Stable helpers exported for focused unit tests and small audit utilities.
canonical_ip = global_v4
normalize_asn = asn_name
rdap_server_for = rdap_server
extract_rdap_holder = rdap_holder
route_objects_text = route_objects
find_shared_flags = shared_flags

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidates", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    result = enrich(args.candidates, args.output_dir, args.workers)
    print(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
